import random, pygame

pygame.init()

#Names the Window
pygame.display.set_caption('Random Map Generator')

#Creates a dictionary for the images
textures = {
    'Dirt' : pygame.image.load('Dirt.png'),
    'Grass' : pygame.image.load('Grass.png'),
    'Sand' : pygame.image.load('Sand.png'),
    'Stone' : pygame.image.load('Stone.png'),
    'Water' : pygame.image.load('Water.png')
}

#Creates a list that can be used as a key
terrain = ['Dirt', 'Grass', 'Sand', 'Stone', 'Water']

#Screen dimensions
tile_size = 64
x_length = 16
y_length = 11
final_x = tile_size*x_length
final_y = tile_size*y_length


screen = pygame.display.set_mode((final_x,final_y))

#For loop containing the random map generation
def tiles():
    for x in range(0,final_x, tile_size):
        for y in range(0,final_y, tile_size):
            key = terrain[random.randint(0, len(terrain) - 1)]
            screen.blit(textures[key],(x,y))

tiles()

#Allows the user to quit the game
done = False
while not done:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            done = True
        if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
            done = True

    pygame.display.update()